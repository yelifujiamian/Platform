package com.xx.togglebutton;

import android.app.Activity;
import android.os.Bundle;
import android.view.WindowManager;

/**
 * Created by eshion on 16-10-14.
 */
public class MainActivity extends Activity{
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.content_main);

    }
}
