#### DroidVR是一个值得把玩的APP
                    
360°全景，即通过对专业相机捕捉整个场景的图像信息或者使用建模软件渲染过后的图片，
使用软件进行图片拼合，并用专门的播放器进行播放，即将平面照片或者计算机建模图片变为360度全观，
用于虚拟现实浏览，把二维的平面图模拟成真实的三维空间，呈现给观赏者。

#### GitHub地址

[https://github.com/sfsheng0322/DroidVR](https://github.com/sfsheng0322/DroidVR) 

#### 关于我

个人邮箱：sfsheng0322@126.com  
[GitHub主页](https://github.com/sfsheng0322)  
[简书主页](http://www.jianshu.com/users/88509e7e2ed1/latest_articles)  
[个人博客](http://sunfusheng.com/)  
[新浪微博](http://weibo.com/u/3852192525)  





















  