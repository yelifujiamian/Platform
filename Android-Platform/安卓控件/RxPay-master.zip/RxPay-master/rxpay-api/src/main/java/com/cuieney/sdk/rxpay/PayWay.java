package com.cuieney.sdk.rxpay;

/**
 * Created by cuieney on 18/08/2017.
 */

public enum  PayWay {
    ALIPAY,
    WECHATPAY
}
