package com.hmy.popwindow.view;

import android.content.Context;
import android.util.AttributeSet;

/**
 * Created by HMY on 2016/9/10.
 */
public class PopDownView extends PopAlertView {

    public PopDownView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }
}
