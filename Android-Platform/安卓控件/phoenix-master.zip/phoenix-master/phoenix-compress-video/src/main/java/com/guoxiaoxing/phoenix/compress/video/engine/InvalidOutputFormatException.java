package com.guoxiaoxing.phoenix.compress.video.engine;

public class InvalidOutputFormatException extends RuntimeException {
    public InvalidOutputFormatException(String detailMessage) {
        super(detailMessage);
    }
}
