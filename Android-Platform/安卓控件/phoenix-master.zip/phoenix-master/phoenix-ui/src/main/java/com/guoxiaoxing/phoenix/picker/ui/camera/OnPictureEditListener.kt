package com.guoxiaoxing.phoenix.picker.ui.camera

interface OnPictureEditListener {

    /**
     * Call when picture editing is complete

     * @param editPath editPath
     */
    fun onEditSucess(editPath: String)
}
