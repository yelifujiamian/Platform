package com.guoxiaoxing.phoenix.picker.util

object Constant {
    val ACTION_AC_FINISH = "app.activity.finish"

    val ACTION_AC_REFRESH_DATA = "app.action.refresh.data"

    val ACTION_CROP_DATA = "app.action.crop_data"

    val ACTION_AC_SINGE_UCROP = "app.activity.singe.ucrop.finish"

    // SD卡写入权限 Flag
    val WRITE_EXTERNAL_STORAGE = 0x01
}
