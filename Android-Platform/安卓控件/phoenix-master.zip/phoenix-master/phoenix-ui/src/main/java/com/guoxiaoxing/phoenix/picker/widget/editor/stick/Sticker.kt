package com.guoxiaoxing.phoenix.picture.edit.widget.stick

enum class Sticker {
    Emoji
}