package com.guoxiaoxing.phoenix.picker.listener

/**
 * For more information, you can visit https://github.com/guoxiaoxing or contact me by
 * guoxiaoxingse@163.com.

 * @author guoxiaoxing
 * *
 * @since 2017/7/27 上午11:39
 */
interface LastOrNextStepListener {
    fun lastOrNext()
}
