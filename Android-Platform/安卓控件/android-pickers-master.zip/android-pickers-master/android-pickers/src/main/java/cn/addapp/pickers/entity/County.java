package cn.addapp.pickers.entity;

/**
 * 区县
 * <br/>
 * Author:matt : addapp.cn
 * DateTime:2016-10-15 19:08
 *
 */
public class County extends ItemBean {
    private String cityId;

    public String getCityId() {
        return cityId;
    }

    public void setCityId(String cityId) {
        this.cityId = cityId;
    }

}
