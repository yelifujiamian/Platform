package cn.addapp.pickers.listeners;

/**
 * @author matt
 * blog: addapp.cn
 */
public interface OnDismissListener {
    public void onDismiss(Object o);
}
