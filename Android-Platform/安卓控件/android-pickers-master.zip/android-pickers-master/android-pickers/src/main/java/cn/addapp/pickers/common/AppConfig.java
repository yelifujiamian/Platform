package cn.addapp.pickers.common;

/**
 * @author matt
 * blog: addapp.cn
 */
public class AppConfig {

    /**
     * @see cn.addapp.pickers.util.LogUtils
     */
    public static final String DEBUG_TAG = "AndroidPicker";// LogCat的标记
    public static final boolean DEBUG_ENABLE = false;// 是否调试模式

}
