package cn.addapp.pickers.listeners;

/**
 * 滑动选中item回调
 * @author matt
 * blog: addapp.cn
 */
public interface OnSingleWheelListener {
    void onWheeled(int index, String item);
}
