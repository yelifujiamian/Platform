package cn.addapp.pickers.listeners;

import android.view.View;

/**
 * @author matt
 * blog: addapp.cn
 */

public interface CustomListener {
    void customLayout(View v);
}
