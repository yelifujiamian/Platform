package cn.addapp.pickers.entity;

/**
 *
 * Author:matt : addapp.cn
 * DateTime:2016-10-15 19:06
 *
 */
public abstract class ItemBean extends JavaBean {
    private String areaId;
    private String areaName;

    public String getAreaId() {
        return areaId;
    }

    public void setAreaId(String areaId) {
        this.areaId = areaId;
    }

    public String getAreaName() {
        return areaName;
    }

    public void setAreaName(String areaName) {
        this.areaName = areaName;
    }

    @Override
    public String toString() {
        return "areaId=" + areaId + ",areaName=" + areaName;
    }
}