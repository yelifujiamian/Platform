package cn.addapp.pickers.model;

/**
 * @author matt
 * blog: addapp.cn
 */
public interface IPickerViewData {
    String getPickerViewText();
}
