
[Binder机制1---Binder原理介绍](http://www.jcodecraeer.com/plus/view.php?aid=2619)　

[Binder机制2---Binder的数据结构以及Binder驱动](http://www.jcodecraeer.com/a/anzhuokaifa/androidkaifa/2015/0319/2620.html)

[Binder机制3---Native层](http://www.jcodecraeer.com/a/anzhuokaifa/androidkaifa/2015/0319/2621.html)

[Binder机制4---Framework层](http://www.jcodecraeer.com/a/anzhuokaifa/androidkaifa/2015/0319/2622.html)

[Binder机制5--- Binder实现进程管理服务示例](http://www.jcodecraeer.com/a/anzhuokaifa/androidkaifa/2015/0319/2623.html)