> Collection家族

![这里写图片描述](http://img.blog.csdn.net/20160408150531095) 



Collection是集合继承结构中的顶层接口

Collections 是提供了对集合进行操作的强大方法的工具类 ，它包含有各种有关集合操作的静态多态方法。此类不能实例化